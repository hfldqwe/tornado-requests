name = "tornado_requests"

from .tornado_requests import requests
