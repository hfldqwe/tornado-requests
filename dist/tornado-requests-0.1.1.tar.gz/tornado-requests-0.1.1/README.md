# Tornado-requests模块  #

这是一个对tornado中异步客户端AsyncHTTPClient进行封装的模块，希望提供更加简洁的api

在使用tornado作为后端接口的同时，希望能够更加轻松的编写**异步爬虫**

详细的文档，你可以参考
[Github项目](https://github.com/hfldqwe/tornado-requests)


